main.py file contains Stand-along Python code
keywords.txt contains symbols such as as AAPL, GOOG, MSFT
The chrome binary is residing in root folder itself
The scraped data is stored in Output.json (Output file)